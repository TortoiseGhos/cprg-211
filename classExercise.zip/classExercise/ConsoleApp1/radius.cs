public class Circle {
    private double rad;
    public double radius{
        set{
            if (value <= 0){
                throw new InvalidRadiusException();
            }
            else{
                rad = value;
            }
        } 
        get {
            return radius;
        }
    }

    public Circle() { 

    }
    public Circle(double r) { 
        this.rad = r;
    }

    public double SetRadius(double r) {
        if (r >= 0) {
            this.rad = r;

        } else {
            throw new InvalidRadiusException();
        }

        return (rad);
        
        }
    
        

        

        public override string ToString() {
            return $"{rad}";
        }


}

public class InvalidRadiusException: Exception {
    public InvalidRadiusException() {
        Console.WriteLine($"The radius is less than or equal to zero");
    }
    public InvalidRadiusException(double radius) {
        Console.WriteLine($"{radius} is not a valid answer");
    }

}

public class Main1 {
    public static void Main(string[] args) {
        Circle radius1 = new Circle();

        try {
            radius1.SetRadius(12.0);
            radius1.SetRadius(0.0);
            radius1.SetRadius(-12.0);
        }
        catch (InvalidRadiusException) {
            Console.WriteLine("not a valid answer");
        }

    }
}